
# FIA Steward – 2D Low-Fi (v4)

Gioco 2D a bassa grafica in cui sei lo steward: decidi bandiere e penalità durante una gara.
Build con avvio robusto (tocco/visibilità/forza avvio) e fallback a timer.

## Come eseguire
Apri `index.html` nel browser oppure pubblica l'intera cartella su GitHub Pages.
